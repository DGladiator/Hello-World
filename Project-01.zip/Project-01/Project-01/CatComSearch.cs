﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project_01
{
    public class CatComSearch
    {
        public string Item { get; set; }
        public string Company { get; set; }
        public string Category { get; set; }
        public int AvilableQuantity { get; set; }
        public int ReorderLevel { get; set; }
    }
}