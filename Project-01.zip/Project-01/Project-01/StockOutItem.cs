﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project_01
{
    public class StockOutItem
    {
        public string ItemName { get; set; }
        public string companyName { get; set; }
        public int Quantity { get; set; }
    }
}