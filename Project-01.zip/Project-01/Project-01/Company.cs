﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project_01
{
    public class Company
    {
        public int SL { get; set; }
        public string Name { get; set; }
    }
}