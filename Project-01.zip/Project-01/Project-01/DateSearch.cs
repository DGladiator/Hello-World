﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project_01
{
    public class DateSearch
    {
        public int SL { get; set; }
        public string Item { get; set; }
        public int SaleQuantity { get; set; }
    }
}